﻿namespace WindowsGame2
{
    using System;

    public class ModelPart
    {
        public string material;
        public int vertexstart;
        public int indexstart;
        public int numvertices;
        public int numindices;
        public bool visible = true;
    }
}

